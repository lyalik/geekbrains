# # # # from word_counter import count_word_occurrences
# # # #
# # # # words = ["apple", "banana", "apple", "orange", "banana", "apple"]
# # # # word_count = count_word_occurrences(words)
# # # #
# # # # print(word_count)
# # #
# # # #2
# # #
# # # from string_utils import remove_consecutive_duplicates
# # #
# # # input_string = "aabbccaa"
# # # output_string = remove_consecutive_duplicates(input_string)
# # #
# # # print(output_string)
# #
# # #3
# #
# # from list_utils import find_unique_elements
# #
# # list1 = [1, 2, 3, 4, 5]
# # list2 = [4, 5, 6, 7, 8]
# #
# # unique_elements = find_unique_elements(list1, list2)
# #
# # print(unique_elements)
#
# #4
#
# from date_utils import is_valid_date
#
# dates = ["29.02.2020", "31.04.2021", "31.12.9999", "01.01.0000", "29.02.1900"]
#
# for date in dates:
#     print(f"{date}: {is_valid_date(date)}")

#5

