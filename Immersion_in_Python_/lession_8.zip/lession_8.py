# from directory_utils import scan_directory
#
# # Пример использования функции
# directory_to_scan = "lession_7"
# scan_directory(directory_to_scan)

#2

# from json_merge_utils import merge_json_files
#
# # Пример использования функции
# input_files = [
#     "employees_part1.json",
#     "employees_part2.json",
#     "employees_part3.json"
# ]
# output_file = "all_employees.json"
#
# merge_json_files(input_files, output_file)

#3

# from json_to_csv_utils import convert_json_to_csv
#
# # Пример использования функции
# json_file = "products.json"
# csv_file = "products.csv"
#
# convert_json_to_csv(json_file, csv_file)

#4
#
# from sales_aggregation_utils import aggregate_sales
#
# # Пример использования функции
# input_csv = "sales.csv"
# output_csv = "total_sales.csv"
#
# aggregate_sales(input_csv, output_csv)